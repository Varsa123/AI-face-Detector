import cv2
import numpy as np
from scipy.spatial.distance import cosine
import pickle
import os

class FaceRecognizer:
    def __init__(self):
        self.embeddings_db = {}
        self.threshold = 0.5
        self.orb = cv2.ORB_create(nfeatures=500)
    
    def get_embedding(self, face_image):
        """Generate embedding using ORB features"""
        gray = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY) if len(face_image.shape) == 3 else face_image
        kp, des = self.orb.detectAndCompute(gray, None)
        
        if des is None:
            # Fallback: use histogram if no features found
            hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
            return cv2.normalize(hist, hist).flatten()
        
        return des.mean(axis=0)
    
    def register_face(self, name, face_image):
        """Register a face in the database"""
        embedding = self.get_embedding(face_image)
        self.embeddings_db[name] = embedding
        print(f"✓ Registered: {name}")
    
    def recognize_face(self, face_image):
        """Recognize a face"""
        embedding = self.get_embedding(face_image)
        
        if not self.embeddings_db:
            return "Unknown", 0.0
        
        min_distance = float('inf')
        recognized_name = "Unknown"
        confidence = 0.0
        
        for name, stored_embedding in self.embeddings_db.items():
            if len(embedding) != len(stored_embedding):
                continue
            distance = cosine(embedding, stored_embedding)
            if distance < min_distance:
                min_distance = distance
                recognized_name = name
                confidence = max(0, 1 - distance)
        
        if min_distance < self.threshold:
            return recognized_name, confidence
        else:
            return "Unknown", 0.0
    
    def save_database(self, filepath):
        """Save embeddings database"""
        with open(filepath, 'wb') as f:
            pickle.dump(self.embeddings_db, f)
    
    def load_database(self, filepath):
        """Load embeddings database"""
        if os.path.exists(filepath):
            with open(filepath, 'rb') as f:
                self.embeddings_db = pickle.load(f)