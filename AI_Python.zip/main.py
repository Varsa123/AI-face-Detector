import cv2
import numpy as np
from face_detector import FaceDetector
from face_recognizer import FaceRecognizer
import os

def main():
    detector = FaceDetector()
    recognizer = FaceRecognizer()
    
    # Load existing embeddings database
    if os.path.exists('embeddings.pkl'):
        recognizer.load_database('embeddings.pkl')
    
    # Start webcam
    cap = cv2.VideoCapture(0)
    
    print("Starting Face Recognition...")
    print("Commands:")
    print("  'r' - Register new face (enter name)")
    print("  'q' - Quit")
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        
        # Detect faces
        faces = detector.detect_faces(frame)
        
        for (x, y, w, h) in faces:
            # Extract and recognize face
            face = detector.extract_face(frame, (x, y, w, h))
            name, confidence = recognizer.recognize_face(face)
            
            # Draw rectangle and label
            color = (0, 255, 0) if name != "Unknown" else (0, 0, 255)
            cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
            cv2.putText(
                frame,
                f"{name} ({confidence:.2f})",
                (x, y-10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                color,
                2
            )
        
        cv2.imshow('Face Recognition', frame)
        
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == ord('r'):
            name = input("Enter name for registration: ")
            if faces:
                (x, y, w, h) = faces[0]
                face = detector.extract_face(frame, (x, y, w, h))
                recognizer.register_face(name, face)
                recognizer.save_database('embeddings.pkl')
    
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()